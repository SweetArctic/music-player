import React, { useEffect, useState } from 'react';
import styled from 'styled-components';
import Player from './components/player';
import PlayerList from './components/PlayerList';
import Modal from './components/animata/overlay/modal';

const AppContainer = styled.div`
  display: flex;
  height: 100vh;
  background-color: #121212;
  font-family: sans-serif;
`;

const LeftPanel = styled.div`
  width: 30%;
  border-right: 1px solid rgba(255, 255, 255, 0.1);
`;

const RightPanel = styled.div`
  width: 70%;
  overflow-y: auto;
`;

const App = () => {
  const [currentSong, setCurrentSong] = useState(0);
  const [playRequested, setPlayRequested] = useState(true);
  const [isPlaying, setIsPlaying] = useState(false);

  useEffect(() => {
    const handlePause = () => {
      setPlayRequested(false);
    };

    window.addEventListener('player-list-pause', handlePause);
    return () => {
      window.removeEventListener('player-list-pause', handlePause);
    };
  }, []);

  return (
    <AppContainer>
      <LeftPanel>
        <Player
          currentSong={currentSong}
          setCurrentSong={setCurrentSong}
          playRequested={playRequested}
          setIsPlaying={setIsPlaying}
        />
      </LeftPanel>
      <RightPanel>
        <Modal />
        <PlayerList
          currentSong={currentSong}
          setCurrentSong={setCurrentSong}
          isPlaying={isPlaying}
          setPlayRequested={setPlayRequested}
        />
      </RightPanel>
    </AppContainer>
  );
};

export default App;