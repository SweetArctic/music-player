import React, { useEffect, useState } from 'react';
import { ListPlus, Play, Pause } from 'lucide-react';
import styled, { keyframes, css } from 'styled-components';
import { songList } from '../data/SongList';
import AnimatedGradientText from '../components/animata/text/animated-gradient-text';

const Wave = styled.div`
  width: 40px;
  height: 40px;
  background-image: url('/animated/audiograma.gif');
  background-size: cover;
  background-repeat: no-repeat;
  background-position: center;
  position: absolute;
  right: 10px;
  top: 50%;
  transform: translateY(-50%);
  opacity: ${({ $isPlaying }) => ($isPlaying ? 1 : 0)};
  transition: opacity 0.4s ease, filter 0.4s ease;
  filter: ${({ $isPlaying }) => ($isPlaying ? 'none' : 'grayscale(1)')};
`;

const Container = styled.div`
  padding: 20px;
  color: white;
`;

const ListItem = styled.div`
  display: flex;
  align-items: center;
  gap: 20px;
  margin-bottom: 16px;
  background-color: ${({ $active }) => ($active ? '#FACB4D' : '#F6644F')};
  padding: 10px;
  border-radius: 8px;
  position: relative;
  transition: background-color 0.3s;
  color: #000000;
`;

const Cover = styled.img`
  width: 50px;
  height: 50px;
  border-radius: 4px;
  object-fit: cover;
`;

const Info = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
`;

const Duration = styled.span`
  font-size: 0.9em;
  opacity: 0.7;
`;

const Button = styled.button`
  margin-top: 20px;
  padding: 10px 20px;
  background: #FACB4D;
  border: none;
  border-radius: 24px;
  cursor: pointer;
  font-weight: bold;
  display: flex;
  align-items: center;
  color: #000000;
`;

const Overlay = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  width: 50px;
  height: 50px;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  border-radius: 4px;
  transition: opacity 0.3s ease;
`;

const CoverWrapper = styled.div`
  position: relative;
  width: 50px;
  height: 50px;

  &:hover ${Overlay} {
    opacity: 1;
  }
`;

const PlayButton = styled.button`
  background: none;
  border: none;
  color: white;
  cursor: pointer;
  transition: transform 0.2s ease;
  display: flex;
  align-items: center;
  justify-content: center;

  &:hover {
    transform: scale(1.2);
  }
`;

const bounceIn = keyframes`
  0% { transform: scale(1); }
  50% { transform: scale(1.3); }
  100% { transform: scale(1); }
`;

const TitleAnimationWrapper = styled.div`
  display: inline-block;
  span {
    display: inline-block;
    animation: ${bounceIn} 0.5s ease;
    animation-fill-mode: both;
  }

  ${({ $autoAnimate }) =>
    $autoAnimate &&
    css`
      span {
        animation-delay: calc(var(--i) * 0.15s);
        animation-iteration-count: 1;
      }
    `}
`;

const formatDuration = (seconds) => {
  const minutes = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60).toString().padStart(2, '0');
  return `${minutes}:${secs}`;
};

const getDuration = (filePath) =>
  new Promise((resolve) => {
    const audio = new Audio(filePath);
    audio.addEventListener('loadedmetadata', () => {
      resolve(formatDuration(audio.duration));
    });
    audio.addEventListener('error', () => resolve('0:00'));
  });

  const PlayerList = ({ currentSong, setCurrentSong, playRequested, setPlayRequested, isPlaying }) => {
  const [songs, setSongs] = useState([]);
  const [autoAnimate, setAutoAnimate] = useState(true);
  

  useEffect(() => {
    const loadDurations = async () => {
      const songsWithDurations = await Promise.all(
        songList.map(async (song) => {
          const duration = await getDuration(song.file);
          return { ...song, duration };
        })
      );
      setSongs(songsWithDurations);
    };

    loadDurations();

    const timeout = setTimeout(() => setAutoAnimate(false), 3000);
    return () => clearTimeout(timeout);
  }, []);

  return (
    <Container>
      <AnimatedGradientText className="text-6xl">
        <TitleAnimationWrapper $autoAnimate={autoAnimate}>
          {'Player Max'.split('').map((char, i) => (
            <span key={i} style={{ '--i': i }}>{char}</span>
          ))}
        </TitleAnimationWrapper>
      </AnimatedGradientText>

      {songs.map((song, index) => (
        <ListItem key={index} $active={currentSong === index}>
          <CoverWrapper>
            <Cover src={song.cover} alt={song.title} />
            <Overlay>
            <PlayButton onClick={() => {
                if (currentSong === index && isPlaying) {
                    setPlayRequested(false);
                    window.dispatchEvent(new Event('player-list-pause'));
                } else {
                    setCurrentSong(index);
                    setPlayRequested(true);
                }
                }}>
                {currentSong === index && isPlaying ? (
                  <Pause size={24} />
                ) : (
                  <Play size={24} />
                )}
              </PlayButton>
            </Overlay>
          </CoverWrapper>
          <Info>
            <span>{song.title}</span>
            <Duration>{song.duration}</Duration>
          </Info>
          {currentSong === index && <Wave $isPlaying={isPlaying} />}
        </ListItem>
      ))}

      <Button onClick={() => alert('Función de playlist próximamente 🎧')}>
        <ListPlus /> Crear Playlist
      </Button>
    </Container>
  );
};

export default PlayerList;
